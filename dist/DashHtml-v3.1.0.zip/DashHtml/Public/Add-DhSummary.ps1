function Add-DhSummary {
    <#
    .SYNOPSIS
        Add a row of KPI metric tiles at the top of the dashboard body.

    .DESCRIPTION
        Renders a horizontal strip of summary cards. Each tile shows an optional
        icon, a formatted value, a label, and an optional sub-label. Tiles can
        be coloured with the same threshold classes used on table cells.

        By default the strip is wrapped in a collapsible container (same chrome
        as Add-DhCollapsible) with a clickable header bar — handy when the
        dashboard has many tiles and you want to give viewers the option to
        fold them away. Pass -Collapsible:$false to render a flat strip with
        no header.

    .PARAMETER Report   Dashboard object from New-DhDashboard.

    .PARAMETER Items
        Array of tile definition hashtables:
          @{
              Label    = 'Caption text'    # REQUIRED
              Value    = 42               # REQUIRED — the main metric
              Icon     = 'X'              # optional emoji / unicode
              SubLabel = 'of 100 total'   # optional small text below label
              Class    = 'cell-danger'    # optional: cell-ok | cell-warn | cell-danger
              Format   = 'number'         # optional: same as column Format values
              Locale   = 'en-US'          # optional BCP-47 locale
              Decimals = 0                # optional decimal places
              Currency = 'USD'            # optional: for Format='currency'

              # ---- Trend / delta indicator (v1.4+) — optional ----
              Previous     = 219          # baseline for auto-computed delta vs Value
              Trend        = 'up'         # 'auto' (default) | 'up' | 'down' | 'flat'
              TrendIsGood  = $true        # $true=force green, $false=force red, omit=semantic default
              DeltaFormat  = 'both'       # 'percent' | 'absolute' | 'both' (default)

              # ---- Sparkline (v1.4+) — optional inline mini-chart below the value ----
              Sparkline      = @(12,18,15,22,19,24,31)  # raw numeric series
              SparklineMin   = 0                         # optional Y-axis min (default: series min)
              SparklineMax   = 100                       # optional Y-axis max (default: series max)
              SparklineStyle = 'line'                    # 'line' (default) | 'area' | 'bars'

              # ---- Tile style — optional ----
              Style    = 'tile'           # 'tile' (default) | 'bignumber' | 'gauge' | 'verdict' | 'score' | 'maturity'
              Caption  = '3 critical'     # bignumber / verdict / score / maturity: small text under the value

              # ---- Verdict (v2.2.0) — Style='verdict', full-width overall assessment ----
              Counts   = @{ critical=3; warning=5; info=2 }   # one chip per non-zero count
                                          # (aliases high/medium/low accepted); without
                                          # Class, the colour follows the worst count

              # ---- Score ring (v2.3.0) — Style='score', a full-width ring with a verdict label ----
              Value    = 69               # the score; numeric (or $null with -Rag NoData)
              Min = 0; Max = 100          # scale (default 0..100); the real number is shown even if outside
              Caption  = 'Elevated risk'  # the label next to the ring
              Facts    = @('211 checks','31 failed')   # one line of small facts
              Previous = 66               # optional: delta vs the last run
              LowerIsBetter = $true       # for a risk score: a drop is shown as an improvement
              NotAssessed   = 20          # optional: checks that could not be assessed; shown beside the
                                          # delta so a score that rose because checks went dark is visible
              Rag      = @{ ... }         # colour bands (same shape as a gauge); or Class

              # ---- Maturity ladder (v2.3.0) — Style='maturity', steps with the current one marked ----
              Levels   = @(@{ Name='Initial'; Description='Ad hoc' }, 'Managed', 'Defined')   # 2 to 10 steps
              Current  = 1                # 0 = no level reached yet; 1..N = the level reached
              Value    = 'Initial'        # text shown as the headline (usually the current level's name)
              Criteria = @(@{ Level=2; Text='Enable the AD Recycle Bin'; Met=$false })   # what the next level needs
          }

    .PARAMETER Collapsible
        Wrap the summary tile strip in a collapsible container with a header
        bar (same look & feel as Add-DhCollapsible). Defaults to $true. Pass
        -Collapsible:$false for a flat strip with no header.

    .PARAMETER Title
        Header text for the collapsible container. Defaults to 'Summary'.
        Only used when -Collapsible is $true.

    .PARAMETER Icon
        Optional emoji / unicode icon shown before the collapsible header
        title. Only used when -Collapsible is $true.

    .PARAMETER DefaultOpen
        Start expanded (default $true). Only used when -Collapsible is $true.

    .EXAMPLE
        Add-DhSummary -Report $report -Items @(
            @{ Label='Total Items';   Value=247;         Icon='X' }
            @{ Label='Active';        Value=231;         Icon='Y'; Class='cell-ok'     }
            @{ Label='Warnings';      Value=12;          Icon='W'; Class='cell-warn'   }
            @{ Label='Critical';      Value=4;           Icon='E'; Class='cell-danger' }
            @{ Label='Monthly Cost';  Value=12450.75;
               Format='currency'; Locale='en-US'; Currency='USD'; Decimals=2 }
            @{ Label='Total Storage'; Value=1610612736;  Format='bytes' }
            @{ Label='Avg Uptime';    Value=99.87;
               Format='percent'; Locale='en-US'; Decimals=2 }
        )

    .EXAMPLE
        # Custom collapsible header — fold away initially
        Add-DhSummary -Report $report -Title 'Key metrics' -Icon 'K' -DefaultOpen $false `
            -Items @(
                @{ Label='Total'; Value=247 }
                @{ Label='Active'; Value=231; Class='cell-ok' }
            )

    .EXAMPLE
        # Opt out of the collapsible chrome — flat tile strip (pre-1.3.2 behaviour)
        Add-DhSummary -Report $report -Collapsible:$false -Items @(
            @{ Label='Total'; Value=247 }
        )
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [System.Collections.Specialized.OrderedDictionary] $Report,
        [Parameter(Mandatory)] [object[]]  $Items,
        [bool]     $Collapsible = $true,
        [string]   $Title       = 'Summary',
        [string]   $Icon        = '',
        [bool]     $DefaultOpen = $true,

        # With -NavPath the strip lives in the block flow of that menu node
        # (shown and hidden with the rest of the node); each node can have its
        # own strip. Without it, the strip is the single one at the top of the page.
        # ---- v2.0.0 navigation (see readme-dev.md section 15) ----
        [string]   $NavPath     = '',   # 'A/B/C' - where this item lives. '//' escapes a literal '/'
        [ValidateSet('','Exact','Subtree','Global')]
        [string]   $NavScope    = '',   # Exact (default) | Subtree (this node and below) | Global (everywhere)
        [string]   $NavLabel    = '',   # display text for this node, decoupled from the path key
        [int]      $NavOrder    = 0,    # explicit sibling ordering; 0 = declaration order
        # Block Id used when -NavPath is set (derived from the path when
        # omitted). Ignored for the top-of-page strip.
        [ValidatePattern('^$|^[A-Za-z0-9_-]+$')]
        [string]   $Id          = ''
    )

    # v2.0.0 - resolve nav declaration once, in one place.
    $navDecl = Resolve-DhNavDeclaration -NavPath $NavPath -NavScope $NavScope `
                    -ItemKind 'Block' -Context 'Add-DhSummary'
    # Monotonic declaration number, shared by tables and blocks. The exporter
    # emits ALL blocks before ALL tables, so without this the menu would order
    # nodes by section type instead of by the order the author wrote them.
    if (-not $Report.Contains('_DhNavSeq')) { $Report['_DhNavSeq'] = 0 }
    $navSeqNo = [int]$Report['_DhNavSeq']; $Report['_DhNavSeq'] = $navSeqNo + 1

    $replacing = $Report.Contains('Summary')

    $normItems = foreach ($item in $Items) {
        if ($item -isnot [hashtable] -and $item -isnot [System.Collections.Specialized.OrderedDictionary]) {
            throw "Add-DhSummary: Each item must be a hashtable. Got: $($item.GetType().Name)"
        }
        if (-not $item.Contains('Label') -or $null -eq $item['Label']) {
            throw "Add-DhSummary: Each item must have a 'Label' key."
        }
        if (-not $item.Contains('Value')) {
            throw "Add-DhSummary: Each item must have a 'Value' key."
        }
        $t = @{} + $item
        if (-not $t.Contains('Icon'))     { $t['Icon']     = '' }
        if (-not $t.Contains('SubLabel')) { $t['SubLabel'] = '' }
        if (-not $t.Contains('Class'))    { $t['Class']    = '' }
        if (-not $t.Contains('Format'))   { $t['Format']   = '' }
        if (-not $t.Contains('Locale'))   { $t['Locale']   = '' }
        if (-not $t.Contains('Decimals')) { $t['Decimals'] = -1 }
        if (-not $t.Contains('Currency')) { $t['Currency'] = '' }

        # ---- Per-tile Action (v1.4.2 — click-to-jump) ----
        # Optional Action=@{TableId;Filter?;Url?;Label?} makes the whole tile
        # clickable. Same shape as Add-DhAlertBanner -Action.
        if ($t.Contains('Action') -and $null -ne $t['Action']) {
            $act = $t['Action']
            if ($act -isnot [hashtable] -and $act -isnot [System.Collections.Specialized.OrderedDictionary]) {
                throw "Add-DhSummary: tile '$($t.Label)' — Action must be a hashtable. Got: $($act.GetType().Name)"
            }
            $hasT = $act.Contains('TableId') -and -not [string]::IsNullOrWhiteSpace([string]$act['TableId'])
            $hasU = $act.Contains('Url')     -and -not [string]::IsNullOrWhiteSpace([string]$act['Url'])
            if (-not $hasT -and -not $hasU) {
                throw "Add-DhSummary: tile '$($t.Label)' — Action requires either a 'TableId' (jump to table) or a 'Url' (external link)."
            }
            if ($hasT -and $hasU) {
                throw "Add-DhSummary: tile '$($t.Label)' — Action must specify EITHER 'TableId' OR 'Url', not both."
            }
            # v1.5.3 — scheme allowlist (same rationale as Add-DhAlertBanner Action.Url).
            $tileUrl = if ($hasU) { Test-DhSafeActionUrl -Url ([string]$act.Url) -Context "Add-DhSummary: tile '$($t.Label)' Action.Url" } else { '' }
            $t['Action'] = @{
                Label   = if ($act.Contains('Label'))  { [string]$act.Label }   else { '' }
                TableId = if ($hasT) { [string]$act.TableId } else { '' }
                Filter  = if ($act.Contains('Filter')) { [string]$act.Filter }  else { '' }
                Url     = $tileUrl
            }
        } else {
            $t['Action'] = $null
        }

        # ---- Tile style dispatch (v1.4 F3 + F4) ----
        if (-not $t.Contains('Style') -or [string]::IsNullOrWhiteSpace([string]$t['Style'])) {
            $t['Style'] = 'tile'
        } else {
            $style = ([string]$t['Style']).ToLowerInvariant()
            if ($style -notin @('tile','bignumber','gauge','verdict','score','maturity')) {
                throw "Add-DhSummary: tile '$($t.Label)' — Style must be 'tile', 'bignumber', 'gauge', 'verdict', 'score' or 'maturity'. Got: $($t['Style'])"
            }
            $t['Style'] = $style
        }

        # ---- Verdict (v2.2.0) — full-width overall assessment with severity chips ----
        # Counts=@{critical=3;warning=5;info=2;ok=0} (aliases high/medium/low
        # accepted). Without an explicit Class the colour follows the worst
        # non-zero count: critical -> cell-danger, warning -> cell-warn, else cell-ok.
        if ($t['Style'] -eq 'verdict') {
            $vc = [ordered]@{}
            if ($t.Contains('Counts') -and $null -ne $t['Counts']) {
                if ($t['Counts'] -isnot [System.Collections.IDictionary]) {
                    throw "Add-DhSummary: tile '$($t.Label)' — Counts must be a hashtable like @{ critical=3; warning=5 }."
                }
                foreach ($k in $t['Counts'].Keys) {
                    $sev = ConvertTo-DhSeverity -Severity ([string]$k) -Context "Add-DhSummary: tile '$($t.Label)' Counts"
                    $cnt = 0
                    if (-not [int]::TryParse([string]$t['Counts'][$k], [ref]$cnt) -or $cnt -lt 0) {
                        throw "Add-DhSummary: tile '$($t.Label)' — Counts.$k must be a whole number >= 0. Got: $($t['Counts'][$k])"
                    }
                    $vc[$sev] = $(if ($vc.Contains($sev)) { $vc[$sev] } else { 0 }) + $cnt
                }
            }
            $t['Counts'] = $vc
            if ([string]::IsNullOrWhiteSpace([string]$t['Class'])) {
                $t['Class'] = if ($vc['critical'] -gt 0) { 'cell-danger' } elseif ($vc['warning'] -gt 0) { 'cell-warn' } else { 'cell-ok' }
            }
        }

        # ---- Score ring (v2.3.0) — Style='score' ----
        # Value/Min/Max/Unit/Rag are validated by the gauge code below (same rules:
        # a missing Value needs Rag NoData). Extras: Facts (one line of small facts),
        # LowerIsBetter (the delta colour only), NotAssessed (checks that went dark).
        if ($t['Style'] -eq 'score') {
            $facts = @(if ($t.Contains('Facts') -and $null -ne $t['Facts']) { @($t['Facts']) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { [string]$_ } })
            $t['Facts'] = $facts
            $t['LowerIsBetter'] = [bool]($t.Contains('LowerIsBetter') -and $t['LowerIsBetter'])
            if ($t.Contains('NotAssessed') -and $null -ne $t['NotAssessed']) {
                $na = 0
                if (-not [int]::TryParse([string]$t['NotAssessed'], [ref]$na) -or $na -lt 0) {
                    throw "Add-DhSummary: tile '$($t.Label)' — NotAssessed must be a whole number >= 0. Got: $($t['NotAssessed'])"
                }
                $t['NotAssessed'] = $na
            } else { $t['NotAssessed'] = $null }
        }

        # ---- Maturity ladder (v2.3.0) — Style='maturity' ----
        # Levels=@(@{Name='Initial';Description='...'}, 'Managed', ...) (2 to 10 steps),
        # Current = 0..N (0 = no level reached yet), optional Criteria=@(@{Level=2;Text='..';Met=$false}).
        if ($t['Style'] -eq 'maturity') {
            if (-not $t.Contains('Levels') -or @($t['Levels']).Count -lt 2 -or @($t['Levels']).Count -gt 10) {
                throw "Add-DhSummary: tile '$($t.Label)' — Style='maturity' needs Levels with 2 to 10 steps."
            }
            $lv = @(foreach ($l in @($t['Levels'])) {
                if ($l -is [System.Collections.IDictionary]) {
                    if (-not $l.Contains('Name') -or [string]::IsNullOrWhiteSpace([string]$l['Name'])) { throw "Add-DhSummary: tile '$($t.Label)' — each Levels hashtable needs a Name." }
                    [ordered]@{ Name = [string]$l['Name']; Description = $(if ($l.Contains('Description')) { [string]$l['Description'] } else { '' }) }
                } else {
                    if ([string]::IsNullOrWhiteSpace([string]$l)) { throw "Add-DhSummary: tile '$($t.Label)' — a Levels entry is empty." }
                    [ordered]@{ Name = [string]$l; Description = '' }
                }
            })
            $t['Levels'] = $lv
            $cur = 0
            if (-not $t.Contains('Current') -or -not [int]::TryParse([string]$t['Current'], [ref]$cur) -or $cur -lt 0 -or $cur -gt $lv.Count) {
                throw "Add-DhSummary: tile '$($t.Label)' — Current must be a whole number from 0 to $($lv.Count) (0 = no level reached). Got: $($t['Current'])"
            }
            $t['Current'] = $cur
            $crit = @(foreach ($c in @($(if ($t.Contains('Criteria')) { $t['Criteria'] } else { $null }))) {
                if ($null -eq $c) { continue }
                if ($c -isnot [System.Collections.IDictionary] -or -not $c.Contains('Text') -or [string]::IsNullOrWhiteSpace([string]$c['Text'])) {
                    throw "Add-DhSummary: tile '$($t.Label)' — each Criteria entry must be @{ Level; Text; Met }."
                }
                $cl = 0
                if (-not $c.Contains('Level') -or -not [int]::TryParse([string]$c['Level'], [ref]$cl) -or $cl -lt 1 -or $cl -gt $lv.Count) {
                    throw "Add-DhSummary: tile '$($t.Label)' — Criteria Level must be 1 to $($lv.Count). Got: $($c['Level'])"
                }
                [ordered]@{ Level = $cl; Text = [string]$c['Text']; Met = [bool]($c.Contains('Met') -and $c['Met']) }
            })
            $t['Criteria'] = $crit
        }

        # Bignumber-specific: optional Caption (small text below the hero value)
        if (-not $t.Contains('Caption')) { $t['Caption'] = '' }

        # ---- Unified Rag → Thresholds + RagNoData (v1.4 F13) ----
        # Done BEFORE the gauge Value check so a null Value combined with
        # Rag.NoData=$true is accepted (gauge renderer paints cell-nodata).
        $t['RagNoData'] = $false
        if ($t.Contains('Rag') -and $null -ne $t['Rag']) {
            $rag = ConvertTo-DhRagThresholds -Rag $t['Rag'] -Context "Add-DhSummary tile '$($t.Label)'"
            $t['Thresholds'] = $rag.Thresholds
            $t['RagNoData']  = $rag.NoData
            # Strip the raw Rag key once consumed — keeps the downstream item shape
            # canonical (Thresholds[] + RagNoData) and avoids double-emit in JSON.
            $t.Remove('Rag')
        }

        # Gauge-specific: Min/Max/Unit/Thresholds
        if ($t['Style'] -in 'gauge', 'score') {
            # Value must be numeric for a gauge — EXCEPT when -Rag NoData=$true is
            # set, in which case a null/missing Value is explicitly allowed and
            # the renderer paints the gauge cell-nodata. Without that opt-in,
            # null/non-numeric is still rejected so authors don't accidentally
            # ship a broken-looking gauge.
            $isMissingValue = ($null -eq $t['Value']) -or ([string]::IsNullOrWhiteSpace([string]$t['Value']))
            $allowNoData = $t.Contains('RagNoData') -and $t['RagNoData']
            if ($isMissingValue -and $allowNoData) {
                # accepted — JS gauge renderer detects the missing value and paints cell-nodata
            } else {
                $gVal = 0.0
                $okGv = [double]::TryParse(
                    [string]$t['Value'],
                    [System.Globalization.NumberStyles]::Float -bor [System.Globalization.NumberStyles]::AllowThousands,
                    [System.Globalization.CultureInfo]::InvariantCulture,
                    [ref]$gVal)
                if (-not $okGv) {
                    throw "Add-DhSummary: tile '$($t.Label)' — Style='$($t['Style'])' requires a numeric Value. Got: $($t['Value']). (Use -Rag with NoData=`$true to allow null values that render as cell-nodata.)"
                }
            }
            # Don't replace $t['Value'] — keep the user's original (could be an int) for the centre readout
        }
        foreach ($k in 'Min','Max') {
            if ($t.Contains($k) -and $null -ne $t[$k]) {
                $n = 0.0
                $okN = [double]::TryParse(
                    [string]$t[$k],
                    [System.Globalization.NumberStyles]::Float -bor [System.Globalization.NumberStyles]::AllowThousands,
                    [System.Globalization.CultureInfo]::InvariantCulture,
                    [ref]$n)
                if (-not $okN) {
                    throw "Add-DhSummary: tile '$($t.Label)' — $k must be a number, got: $($t[$k])"
                }
                $t[$k] = $n
            } else {
                # Gauge defaults: 0..100. Other styles ignore Min/Max.
                $t[$k] = if ($t['Style'] -in 'gauge', 'score') { if ($k -eq 'Min') { 0.0 } else { 100.0 } } else { $null }
            }
        }
        if (-not $t.Contains('Unit')) { $t['Unit'] = '' }

        # Thresholds for gauge — array of @{ Min=..; Max=..; Class='cell-...' }
        # Same shape as Add-DhTable column thresholds (numeric only — string Value
        # thresholds don't apply to a numeric gauge).
        # When -Rag was used above, Thresholds is already populated and validated;
        # this block is the fallback path for legacy Thresholds=@(...) callers
        # plus a defensive re-validation of Rag-derived thresholds.
        $thOut = @()
        if ($t.Contains('Thresholds') -and $t['Thresholds']) {
            foreach ($th in @($t['Thresholds'])) {
                if ($th -isnot [hashtable] -and $th -isnot [System.Collections.Specialized.OrderedDictionary]) {
                    throw "Add-DhSummary: tile '$($t.Label)' — each Thresholds entry must be a hashtable. Got: $($th.GetType().Name)"
                }
                if (-not $th.Contains('Class') -or [string]::IsNullOrWhiteSpace([string]$th['Class'])) {
                    throw "Add-DhSummary: tile '$($t.Label)' — each Thresholds entry must have a non-empty Class key."
                }
                $thHash = @{ Class = [string]$th['Class'] }
                foreach ($bk in 'Min','Max') {
                    if ($th.Contains($bk) -and $null -ne $th[$bk]) {
                        $n = 0.0
                        $okN = [double]::TryParse(
                            [string]$th[$bk],
                            [System.Globalization.NumberStyles]::Float -bor [System.Globalization.NumberStyles]::AllowThousands,
                            [System.Globalization.CultureInfo]::InvariantCulture,
                            [ref]$n)
                        if (-not $okN) {
                            throw "Add-DhSummary: tile '$($t.Label)' — threshold $bk must be a number, got: $($th[$bk])"
                        }
                        $thHash[$bk] = $n
                    }
                }
                $thOut += $thHash
            }
        }
        $t['Thresholds'] = @($thOut)

        # ---- Trend / delta indicator (v1.4 F1) ----
        # Previous (nullable number). Triggers auto-derived delta when present.
        # IMPORTANT: parse with InvariantCulture — PowerShell [string] on a double
        # uses invariant format (period decimal), but [double]::TryParse defaults
        # to CurrentCulture which on locales like it-IT treats period as the
        # thousands separator, silently turning 92330.25 into 9233025.
        if ($t.Contains('Previous') -and $null -ne $t['Previous']) {
            $n = 0.0
            $okN = [double]::TryParse(
                [string]$t['Previous'],
                [System.Globalization.NumberStyles]::Float -bor [System.Globalization.NumberStyles]::AllowThousands,
                [System.Globalization.CultureInfo]::InvariantCulture,
                [ref]$n)
            if (-not $okN) {
                throw "Add-DhSummary: tile '$($t.Label)' — Previous must be a number, got: $($t['Previous'])"
            }
            $t['Previous'] = $n
        } else {
            $t['Previous'] = $null
        }

        # Trend ('auto' default | 'up' | 'down' | 'flat'). 'auto' = derive from Previous/Value.
        if (-not $t.Contains('Trend') -or [string]::IsNullOrWhiteSpace([string]$t['Trend'])) {
            $t['Trend'] = 'auto'
        } else {
            $trend = ([string]$t['Trend']).ToLowerInvariant()
            if ($trend -notin @('auto','up','down','flat')) {
                throw "Add-DhSummary: tile '$($t.Label)' — Trend must be 'auto', 'up', 'down', or 'flat'. Got: $($t['Trend'])"
            }
            $t['Trend'] = $trend
        }

        # TrendIsGood (nullable bool). $null = semantic default in JS (up=good, down=bad, flat=neutral).
        if ($t.Contains('TrendIsGood') -and $null -ne $t['TrendIsGood']) {
            $t['TrendIsGood'] = [bool]$t['TrendIsGood']
        } else {
            $t['TrendIsGood'] = $null
        }

        # DeltaFormat ('percent' | 'absolute' | 'both' default).
        if (-not $t.Contains('DeltaFormat') -or [string]::IsNullOrWhiteSpace([string]$t['DeltaFormat'])) {
            $t['DeltaFormat'] = 'both'
        } else {
            $df = ([string]$t['DeltaFormat']).ToLowerInvariant()
            if ($df -notin @('percent','absolute','both')) {
                throw "Add-DhSummary: tile '$($t.Label)' — DeltaFormat must be 'percent', 'absolute', or 'both'. Got: $($t['DeltaFormat'])"
            }
            $t['DeltaFormat'] = $df
        }

        # ---- Sparkline (v1.4 F2) — optional inline mini-chart below the value ----
        # Normalise the series into a numeric array. Anything not parseable as a
        # number is dropped (with a warning) so a bad value doesn't break the SVG.
        # NOTE: parse with InvariantCulture (see Previous note above).
        $sparkArr = @()
        if ($t.Contains('Sparkline') -and $null -ne $t['Sparkline']) {
            $raw = @($t['Sparkline'])
            foreach ($v in $raw) {
                if ($null -eq $v) { continue }
                $n = 0.0
                $okN = [double]::TryParse(
                    [string]$v,
                    [System.Globalization.NumberStyles]::Float -bor [System.Globalization.NumberStyles]::AllowThousands,
                    [System.Globalization.CultureInfo]::InvariantCulture,
                    [ref]$n)
                if ($okN) {
                    $sparkArr += $n
                } else {
                    Write-Warning "Add-DhSummary: tile '$($t.Label)' — Sparkline value '$v' is not numeric and will be skipped."
                }
            }
        }
        $t['Sparkline'] = @($sparkArr)

        # Optional numeric Y-axis bounds — leave as $null when not supplied so JS uses series min/max
        foreach ($k in 'SparklineMin','SparklineMax') {
            if ($t.Contains($k) -and $null -ne $t[$k]) {
                $n = 0.0
                $okN = [double]::TryParse(
                    [string]$t[$k],
                    [System.Globalization.NumberStyles]::Float -bor [System.Globalization.NumberStyles]::AllowThousands,
                    [System.Globalization.CultureInfo]::InvariantCulture,
                    [ref]$n)
                if (-not $okN) {
                    throw "Add-DhSummary: tile '$($t.Label)' — $k must be a number, got: $($t[$k])"
                }
                $t[$k] = $n
            } else {
                $t[$k] = $null
            }
        }

        # Style — 'line' (default) | 'area' | 'bars'
        if (-not $t.Contains('SparklineStyle') -or [string]::IsNullOrWhiteSpace([string]$t['SparklineStyle'])) {
            $t['SparklineStyle'] = 'line'
        } else {
            $style = ([string]$t['SparklineStyle']).ToLowerInvariant()
            if ($style -notin @('line','area','bars')) {
                throw "Add-DhSummary: tile '$($t.Label)' — SparklineStyle must be 'line', 'area', or 'bars'. Got: $($t['SparklineStyle'])"
            }
            $t['SparklineStyle'] = $style
        }

        $t
    }

    # ---- Storage: per-node strip OR the top-of-page singleton ----
    if (@($navDecl.Path).Count -eq 0) {
        # Page-global singleton at the top of the page (unchanged from v1.4.0).
        $Report['Summary'] = @($normItems)
        $Report['SummaryOptions'] = [ordered]@{
            Collapsible = $Collapsible
            Title       = $Title
            Icon        = $Icon
            DefaultOpen = $DefaultOpen
        }
        if ($replacing) {
            Write-Warning "Add-DhSummary: Report already has a global Summary - replacing the existing tiles. (Pass -NavPath to add a strip to one menu node instead.)"
        }
        Write-Verbose "Add-DhSummary: $(@($normItems).Count) tile(s) added at top-of-page.$(if ($Collapsible) { ' (collapsible)' } else { ' (flat)' })"
    } else {
        # Per-node strip; lives in $Report.Blocks so the nav
        # routing hides / shows it with the rest of the panel content.
        if (-not $Report.Contains('Blocks')) {
            $Report['Blocks'] = [System.Collections.Generic.List[hashtable]]::new()
        }
        # Derive the Id from the menu path if the caller didn't supply one.
        # Slugify (lowercase + non-alphanum to '-'): 'My Group' → 'my-group'.
        function _slug([string] $s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return '' }
            return ($s.ToLowerInvariant() -replace '[^a-z0-9_-]','-').Trim('-')
        }
        $blockId = $Id
        if ([string]::IsNullOrWhiteSpace($blockId)) {
            $blockId = 'summary-' + ((@($navDecl.Path) | ForEach-Object { _slug $_ }) -join '-')
        }
        # Duplicate-Id guard mirroring the other block cmdlets
        foreach ($existing in $Report.Blocks) {
            if ($existing.Id -eq $blockId) {
                throw "Add-DhSummary: A block with Id '$blockId' already exists. Supply -Id to disambiguate, or pick a different -NavPath."
            }
        }
        $Report.Blocks.Add([ordered]@{
            BlockType   = 'summarystrip'
            Id          = $blockId
            Title       = $Title
            Icon        = $Icon
            Items       = @($normItems)
            Collapsible = [bool]$Collapsible
            DefaultOpen = [bool]$DefaultOpen
            NavPath     = $NavPath
            NavSegments     = $navDecl.Path
            NavSeqNo     = $navSeqNo
            NavScope    = $navDecl.Scope
            NavLabel    = $NavLabel
            NavOrder    = $NavOrder
        })
        Write-Verbose "Add-DhSummary: $(@($normItems).Count) tile(s) added as block '$blockId' (NavPath='$(@($navDecl.Path) -join '/')')."
    }
}



